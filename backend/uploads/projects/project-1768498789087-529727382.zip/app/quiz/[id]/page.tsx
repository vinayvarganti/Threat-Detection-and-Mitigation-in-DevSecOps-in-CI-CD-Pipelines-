"use client"
import { useParams, useRouter } from "next/navigation"
import { QuizInterface } from "@/components/quiz-interface"
import { quizData } from "@/lib/quiz-data"

export default function QuizPage() {
  const params = useParams()
  const router = useRouter()
  const quizId = params.id as string

  const quiz = quizData[quizId as keyof typeof quizData]

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Quiz not found</h1>
          <button onClick={() => router.push("/")} className="text-primary hover:underline">
            Back to courses
          </button>
        </div>
      </div>
    )
  }

  return <QuizInterface quiz={quiz} />
}
