import { QuizListing } from "@/components/quiz-listing"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <QuizListing />
    </main>
  )
}
