"use client"

import { useParams, useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { ResultsDisplay } from "@/components/results-display"
import type { QuizResult } from "@/lib/scoring"

export default function ResultsPage() {
  const params = useParams()
  const router = useRouter()
  const quizId = params.id as string
  const [result, setResult] = useState<QuizResult | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedResult = sessionStorage.getItem("quizResult")
    if (storedResult) {
      const parsed = JSON.parse(storedResult)
      if (parsed.quizId === quizId) {
        setResult(parsed)
      }
    }
    setIsLoading(false)
  }, [quizId])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading your results...</p>
        </div>
      </div>
    )
  }

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">No results found</h1>
          <p className="text-muted-foreground mb-6">Please complete a quiz first.</p>
          <button onClick={() => router.push("/")} className="text-primary hover:underline font-medium">
            Back to courses
          </button>
        </div>
      </div>
    )
  }

  return <ResultsDisplay result={result} />
}
