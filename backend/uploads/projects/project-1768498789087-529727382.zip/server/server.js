import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import sequelize from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import quizRoutes from "./routes/quizRoutes.js";
import resultRoutes from "./routes/resultRoutes.js";

import User from "./models/User.js";
import Quiz from "./models/Quiz.js";
import Question from "./models/Question.js";
import Result from "./models/Result.js";

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

/* Associations */
Quiz.hasMany(Question, { onDelete: "CASCADE" });
Question.belongsTo(Quiz);

User.hasMany(Result);
Result.belongsTo(User);

Quiz.hasMany(Result);
Result.belongsTo(Quiz);

/* Routes */
app.use("/api/auth", authRoutes);
app.use("/api/quiz", quizRoutes);
app.use("/api/result", resultRoutes);

const PORT = process.env.PORT || 5000;
sequelize.sync({ alter: true }).then(() => {
  console.log("Database synced");
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error("Unable to connect to DB:", err);
});
