import express from "express";
import { submitQuiz, getResultsForUser } from "../controllers/resultController.js";
import auth from "../middleware/authMiddleware.js";
const router = express.Router();

router.post("/:id/submit", auth, submitQuiz);
router.get("/mine", auth, getResultsForUser);

export default router;
