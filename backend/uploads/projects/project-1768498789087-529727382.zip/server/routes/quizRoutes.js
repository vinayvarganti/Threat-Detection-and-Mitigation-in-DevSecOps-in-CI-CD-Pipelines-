import express from "express";
import { createQuiz, addQuestion, getQuizzes, getQuizWithQuestions } from "../controllers/quizController.js";
import auth from "../middleware/authMiddleware.js";
const router = express.Router();

router.get("/", getQuizzes);
router.post("/", auth, createQuiz);
router.get("/:id", getQuizWithQuestions);
router.post("/:id/question", auth, addQuestion);

export default router;
