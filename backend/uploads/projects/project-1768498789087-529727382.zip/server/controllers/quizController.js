import Quiz from "../models/Quiz.js";
import Question from "../models/Question.js";

export const createQuiz = async (req, res) => {
  try {
    const { title, description } = req.body;
    const quiz = await Quiz.create({ title, description });
    res.json(quiz);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const addQuestion = async (req, res) => {
  try {
    const quizId = req.params.id;
    const { questionText, options, correctAnswer } = req.body;
    const question = await Question.create({ questionText, options, correctAnswer, QuizId: quizId });
    res.json(question);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getQuizzes = async (req, res) => {
  try {
    const quizzes = await Quiz.findAll();
    res.json(quizzes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getQuizWithQuestions = async (req, res) => {
  try {
    const id = req.params.id;
    const quiz = await Quiz.findByPk(id, { include: [Question]});
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });
    // hide correct answers when sending to client
    const quizData = quiz.toJSON();
    quizData.Questions = quizData.Questions.map(q => {
      const { correctAnswer, ...rest } = q;
      return rest;
    });
    res.json(quizData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
