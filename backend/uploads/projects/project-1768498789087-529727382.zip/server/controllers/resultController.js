import Result from "../models/Result.js";
import Quiz from "../models/Quiz.js";
import Question from "../models/Question.js";

export const submitQuiz = async (req, res) => {
  try {
    const quizId = req.params.id;
    const { answers } = req.body; // expected { questionId: selectedOption, ... }
    const userId = req.user.id;

    const questions = await Question.findAll({ where: { QuizId: quizId }});
    let score = 0;
    questions.forEach(q => {
      const selected = answers[q.id];
      if (selected && String(selected) === String(q.correctAnswer)) score += 1;
    });

    const result = await Result.create({ score, UserId: userId, QuizId: quizId });
    res.json({ score, resultId: result.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getResultsForUser = async (req, res) => {
  try {
    const userId = req.user.id;
    const results = await Result.findAll({ where: { UserId: userId }, include: [Quiz]});
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
