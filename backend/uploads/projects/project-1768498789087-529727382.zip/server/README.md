# Quiz Platform - Backend (Node.js + Express + MySQL)

## Quick start

1. Rename `.env.example` to `.env` and set your MySQL credentials.
2. Install dependencies:
   ```
   cd server
   npm install
   ```
3. Run in development:
   ```
   npm run dev
   ```
4. The server will run on `http://localhost:5000` by default.

## API endpoints (overview)

- `POST /api/auth/register` { username, password }
- `POST /api/auth/login` { username, password } -> returns token
- `GET /api/quiz` -> list quizzes
- `POST /api/quiz` (auth) -> { title, description }
- `GET /api/quiz/:id` -> quiz with (hidden) questions
- `POST /api/quiz/:id/question` (auth) -> { questionText, options, correctAnswer }
- `POST /api/result/:id/submit` (auth) -> { answers: { questionId: selectedOption } }
- `GET /api/result/mine` (auth) -> user's results

