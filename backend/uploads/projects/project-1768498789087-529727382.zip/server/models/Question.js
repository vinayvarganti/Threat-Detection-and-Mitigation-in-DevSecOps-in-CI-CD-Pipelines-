import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const Question = sequelize.define("Question", {
  questionText: { type: DataTypes.TEXT, allowNull: false },
  options: { type: DataTypes.JSON, allowNull: false }, 
  correctAnswer: { type: DataTypes.STRING, allowNull: false }
});

export default Question;
