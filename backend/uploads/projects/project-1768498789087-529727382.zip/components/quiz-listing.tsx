"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { BookOpen, Clock, Award } from "lucide-react"
import { useAuth } from "@/components/auth-context"
import { useRouter } from "next/navigation"
import { UserMenu } from "@/components/user-menu"

interface Quiz {
  id: string
  title: string
  description: string
  category: string
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  duration: number
  questions: number
  passingScore: number
}

const quizzes: Quiz[] = [
  {
    id: "web-basics",
    title: "Web Development Fundamentals",
    description:
      "Learn the basics of HTML, CSS, and JavaScript. Perfect for beginners starting their web development journey.",
    category: "Web Development",
    difficulty: "Beginner",
    duration: 30,
    questions: 20,
    passingScore: 70,
  },
  {
    id: "react-advanced",
    title: "Advanced React Patterns",
    description: "Master advanced React concepts including hooks, context, and performance optimization.",
    category: "React",
    difficulty: "Advanced",
    duration: 45,
    questions: 25,
    passingScore: 75,
  },
  {
    id: "typescript-essentials",
    title: "TypeScript Essentials",
    description: "Understand TypeScript fundamentals and how to use types effectively in your projects.",
    category: "TypeScript",
    difficulty: "Intermediate",
    duration: 35,
    questions: 22,
    passingScore: 70,
  },
  {
    id: "nextjs-fullstack",
    title: "Next.js Full Stack Development",
    description: "Build complete full-stack applications with Next.js, including API routes and database integration.",
    category: "Next.js",
    difficulty: "Advanced",
    duration: 50,
    questions: 30,
    passingScore: 75,
  },
  {
    id: "css-mastery",
    title: "CSS Mastery",
    description: "Deep dive into CSS including flexbox, grid, animations, and responsive design techniques.",
    category: "CSS",
    difficulty: "Intermediate",
    duration: 40,
    questions: 24,
    passingScore: 70,
  },
  {
    id: "database-design",
    title: "Database Design & SQL",
    description: "Learn database design principles, normalization, and write efficient SQL queries.",
    category: "Databases",
    difficulty: "Intermediate",
    duration: 45,
    questions: 26,
    passingScore: 72,
  },
]

const difficultyColors: Record<string, string> = {
  Beginner: "bg-green-500/20 text-green-700 dark:text-green-400",
  Intermediate: "bg-yellow-500/20 text-yellow-700 dark:text-yellow-400",
  Advanced: "bg-red-500/20 text-red-700 dark:text-red-400",
}

export function QuizListing() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const { user, isLoading } = useAuth()
  const router = useRouter()

  if (!isLoading && !user) {
    router.push("/login")
    return null
  }

  const categories = Array.from(new Set(quizzes.map((q) => q.category)))
  const filteredQuizzes = selectedCategory ? quizzes.filter((q) => q.category === selectedCategory) : quizzes

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">LearnHub</h1>
                <p className="text-sm text-muted-foreground">Master new skills with our certification courses</p>
              </div>
            </div>
            <UserMenu />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Category Filter */}
        <div className="mb-12">
          <h2 className="text-lg font-semibold text-foreground mb-4">Filter by Category</h2>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="rounded-full"
            >
              All Courses
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className="rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Quiz Grid */}
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-8">
            {selectedCategory ? `${selectedCategory} Courses` : "All Courses"}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes.map((quiz) => (
              <Card
                key={quiz.id}
                className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300 border-border/50 bg-card/80 backdrop-blur-sm"
              >
                {/* Card Header */}
                <div className="p-6 pb-4 border-b border-border/30">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <h3 className="text-lg font-bold text-foreground leading-tight flex-1">{quiz.title}</h3>
                    <Badge className={`${difficultyColors[quiz.difficulty]} border-0 whitespace-nowrap`}>
                      {quiz.difficulty}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{quiz.description}</p>
                </div>

                {/* Card Body */}
                <div className="p-6 flex-1">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{quiz.duration} minutes</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <BookOpen className="w-4 h-4" />
                      <span>{quiz.questions} questions</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Award className="w-4 h-4" />
                      <span>{quiz.passingScore}% to pass</span>
                    </div>
                  </div>
                </div>

                {/* Card Footer */}
                <div className="p-6 pt-4 border-t border-border/30">
                  <Link href={`/quiz/${quiz.id}`} className="w-full">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                      Start Quiz
                    </Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Empty State */}
        {filteredQuizzes.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">No courses found in this category.</p>
          </div>
        )}
      </div>
    </div>
  )
}
