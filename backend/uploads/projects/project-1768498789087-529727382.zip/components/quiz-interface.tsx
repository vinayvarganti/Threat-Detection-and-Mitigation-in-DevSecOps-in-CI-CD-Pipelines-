"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Clock, ChevronRight, ChevronLeft, AlertCircle } from "lucide-react"
import type { Quiz } from "@/lib/quiz-data"
import { calculateScore } from "@/lib/scoring"

interface QuizInterfaceProps {
  quiz: Quiz
}

export function QuizInterface({ quiz }: QuizInterfaceProps) {
  const router = useRouter()
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [timeLeft, setTimeLeft] = useState(quiz.duration * 60)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const currentQuestion = quiz.questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100
  const isAnswered = currentQuestionIndex in answers
  const isLastQuestion = currentQuestionIndex === quiz.questions.length - 1

  // Timer
  useEffect(() => {
    if (timeLeft <= 0) {
      handleSubmit()
      return
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleSelectAnswer = (optionIndex: number) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestionIndex]: optionIndex,
    }))
  }

  const handleNext = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1)
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    let correctCount = 0
    quiz.questions.forEach((question, index) => {
      if (answers[index] === question.correctAnswer) {
        correctCount++
      }
    })

    const score = calculateScore(correctCount, quiz.questions.length)
    const passed = score >= quiz.passingScore

    // Store result in session storage
    sessionStorage.setItem(
      "quizResult",
      JSON.stringify({
        quizId: quiz.id,
        quizTitle: quiz.title,
        score,
        passed,
        correctCount,
        totalQuestions: quiz.questions.length,
        timestamp: new Date().toISOString(),
      }),
    )

    router.push(`/results/${quiz.id}`)
  }

  const isTimeWarning = timeLeft < 300 // 5 minutes

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground">{quiz.title}</h1>
              <p className="text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {quiz.questions.length}
              </p>
            </div>
            <div
              className={`flex items-center gap-2 px-4 py-2 rounded-lg ${isTimeWarning ? "bg-red-500/20" : "bg-muted"}`}
            >
              <Clock
                className={`w-5 h-5 ${isTimeWarning ? "text-red-600 dark:text-red-400" : "text-muted-foreground"}`}
              />
              <span
                className={`font-mono font-semibold ${isTimeWarning ? "text-red-600 dark:text-red-400" : "text-foreground"}`}
              >
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8">
          {/* Question */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">{currentQuestion.question}</h2>

            {/* Options */}
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleSelectAnswer(index)}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left font-medium ${
                    answers[currentQuestionIndex] === index
                      ? "border-primary bg-primary/10 text-foreground"
                      : "border-border/50 bg-muted/30 text-foreground hover:border-primary/50 hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                        answers[currentQuestionIndex] === index ? "border-primary bg-primary" : "border-border/50"
                      }`}
                    >
                      {answers[currentQuestionIndex] === index && (
                        <div className="w-2 h-2 bg-primary-foreground rounded-full" />
                      )}
                    </div>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between pt-8 border-t border-border/30">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentQuestionIndex === 0}
              className="gap-2 bg-transparent"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>

            <div className="flex gap-2">
              {!isAnswered && (
                <div className="flex items-center gap-2 text-sm text-yellow-600 dark:text-yellow-400 bg-yellow-500/10 px-3 py-2 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span>Please answer this question</span>
                </div>
              )}
            </div>

            {isLastQuestion ? (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground">Submit Quiz</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogTitle>Submit Quiz?</AlertDialogTitle>
                  <AlertDialogDescription>
                    You have answered {Object.keys(answers).length} out of {quiz.questions.length} questions.
                    {Object.keys(answers).length < quiz.questions.length && (
                      <div className="mt-2 text-yellow-600 dark:text-yellow-400">
                        Some questions are unanswered. You can still submit.
                      </div>
                    )}
                  </AlertDialogDescription>
                  <div className="flex gap-3 justify-end">
                    <AlertDialogCancel>Continue</AlertDialogCancel>
                    <AlertDialogAction onClick={handleSubmit} className="bg-primary">
                      Submit
                    </AlertDialogAction>
                  </div>
                </AlertDialogContent>
              </AlertDialog>
            ) : (
              <Button onClick={handleNext} className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground">
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </Card>

        {/* Question Navigator */}
        <div className="mt-8">
          <h3 className="text-sm font-semibold text-foreground mb-4">Question Navigator</h3>
          <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2">
            {quiz.questions.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentQuestionIndex(index)}
                className={`aspect-square rounded-lg font-semibold text-sm transition-all ${
                  index === currentQuestionIndex
                    ? "bg-primary text-primary-foreground ring-2 ring-primary/50"
                    : index in answers
                      ? "bg-success text-success-foreground hover:bg-success/90"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {index + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
