"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { determinePerformance, generateCertificateData } from "@/lib/scoring"
import { generateCertificatePDF } from "@/lib/pdf-generator"
import { Download, Home, RotateCcw, Award, CheckCircle2, XCircle } from "lucide-react"
import type { QuizResult } from "@/lib/scoring"

interface ResultsDisplayProps {
  result: QuizResult
}

export function ResultsDisplay({ result }: ResultsDisplayProps) {
  const router = useRouter()
  const performance = determinePerformance(result.score)
  const certificateData = generateCertificateData(result)
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDownloadCertificate = async () => {
    setIsDownloading(true)
    try {
      await generateCertificatePDF(result)
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("Failed to generate certificate. Please try again.")
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-2xl font-bold text-foreground">Quiz Results</h1>
          <p className="text-sm text-muted-foreground">{result.quizTitle}</p>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Score Card */}
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8 mb-8 text-center">
          <div className="mb-6">
            {result.passed ? (
              <div className="w-20 h-20 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-12 h-12 text-success" />
              </div>
            ) : (
              <div className="w-20 h-20 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-12 h-12 text-red-600 dark:text-red-400" />
              </div>
            )}
          </div>

          <h2 className={`text-4xl font-bold mb-2 ${performance.color}`}>{result.score}%</h2>
          <p className={`text-lg font-semibold mb-4 ${performance.color}`}>{performance.level}</p>
          <p className="text-muted-foreground mb-6">{performance.message}</p>

          {result.passed && (
            <Badge className="bg-success text-success-foreground border-0 mb-6">
              <Award className="w-4 h-4 mr-2" />
              Certification Earned
            </Badge>
          )}
        </Card>

        {/* Score Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <p className="text-sm text-muted-foreground mb-2">Correct Answers</p>
            <p className="text-3xl font-bold text-success">{result.correctCount}</p>
            <p className="text-xs text-muted-foreground mt-2">out of {result.totalQuestions}</p>
          </Card>

          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <p className="text-sm text-muted-foreground mb-2">Accuracy Rate</p>
            <p className="text-3xl font-bold text-primary">{result.score}%</p>
            <p className="text-xs text-muted-foreground mt-2">of questions answered correctly</p>
          </Card>

          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <p className="text-sm text-muted-foreground mb-2">Passing Score</p>
            <p className="text-3xl font-bold text-accent">70%</p>
            <p className="text-xs text-muted-foreground mt-2">required to pass</p>
          </Card>
        </div>

        {/* Certificate Section */}
        {result.passed && (
          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8 mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-foreground mb-2">Your Certificate</h3>
                <p className="text-sm text-muted-foreground">Certificate ID: {certificateData.certificateId}</p>
              </div>
              <Award className="w-12 h-12 text-primary opacity-20" />
            </div>

            <div className="bg-muted/30 rounded-lg p-6 mb-6 border border-border/30">
              <p className="text-sm text-muted-foreground mb-2">Issued Date</p>
              <p className="font-semibold text-foreground">{certificateData.issuedDate}</p>
              <p className="text-sm text-muted-foreground mt-4 mb-2">Valid Until</p>
              <p className="font-semibold text-foreground">{certificateData.expiryDate}</p>
            </div>

            <Button
              onClick={handleDownloadCertificate}
              disabled={isDownloading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
            >
              <Download className="w-4 h-4" />
              {isDownloading ? "Generating..." : "Download Certificate (PDF)"}
            </Button>
          </Card>
        )}

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Button onClick={() => router.push("/")} variant="outline" className="flex-1 gap-2 bg-transparent">
            <Home className="w-4 h-4" />
            Back to Courses
          </Button>

          {!result.passed && (
            <Button
              onClick={() => router.push(`/quiz/${result.quizId}`)}
              className="flex-1 gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </Button>
          )}

          {result.passed && (
            <Button
              onClick={() => router.push("/")}
              className="flex-1 gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Explore More Courses
            </Button>
          )}
        </div>

        {/* Result Details */}
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8 mt-8">
          <h3 className="text-lg font-bold text-foreground mb-6">Performance Summary</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <span className="text-muted-foreground">Quiz Title</span>
              <span className="font-semibold text-foreground">{result.quizTitle}</span>
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <span className="text-muted-foreground">Total Questions</span>
              <span className="font-semibold text-foreground">{result.totalQuestions}</span>
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <span className="text-muted-foreground">Correct Answers</span>
              <span className="font-semibold text-success">{result.correctCount}</span>
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <span className="text-muted-foreground">Incorrect Answers</span>
              <span className="font-semibold text-red-600 dark:text-red-400">
                {result.totalQuestions - result.correctCount}
              </span>
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-border/30">
              <span className="text-muted-foreground">Final Score</span>
              <span className="font-semibold text-primary">{result.score}%</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Status</span>
              <Badge
                className={
                  result.passed
                    ? "bg-success text-success-foreground border-0"
                    : "bg-red-500/20 text-red-700 dark:text-red-400 border-0"
                }
              >
                {result.passed ? "Passed" : "Failed"}
              </Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
