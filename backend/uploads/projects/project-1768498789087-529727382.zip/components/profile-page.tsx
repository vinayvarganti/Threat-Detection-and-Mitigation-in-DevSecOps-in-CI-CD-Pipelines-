"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-context"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ArrowLeft, Mail, Calendar, Award, BookOpen } from "lucide-react"

export function ProfilePage() {
  const router = useRouter()
  const { user } = useAuth()

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Not authenticated</h1>
          <Button onClick={() => router.push("/login")} className="mt-4">
            Go to Login
          </Button>
        </div>
      </div>
    )
  }

  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()

  const memberSince = new Date(user.createdAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="h-10 w-10 rounded-full">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">My Profile</h1>
              <p className="text-sm text-muted-foreground">Manage your account and view your progress</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Card */}
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <Avatar className="h-24 w-24 bg-primary text-primary-foreground">
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1">
              <h2 className="text-3xl font-bold text-foreground mb-2">{user.name}</h2>
              <div className="flex flex-col gap-2 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>{user.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Member since {memberSince}</span>
                </div>
              </div>
            </div>

            <Button onClick={() => router.push("/")} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Back to Courses
            </Button>
          </div>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Quizzes Completed</p>
                <p className="text-3xl font-bold text-foreground">0</p>
              </div>
              <BookOpen className="w-10 h-10 text-primary opacity-20" />
            </div>
          </Card>

          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Certificates Earned</p>
                <p className="text-3xl font-bold text-success">0</p>
              </div>
              <Award className="w-10 h-10 text-success opacity-20" />
            </div>
          </Card>

          <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Average Score</p>
                <p className="text-3xl font-bold text-primary">--</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-sm font-bold text-primary">%</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Account Settings */}
        <Card className="border-border/50 bg-card/80 backdrop-blur-sm p-8">
          <h3 className="text-lg font-bold text-foreground mb-6">Account Information</h3>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Full Name</label>
              <div className="p-3 rounded-lg bg-muted/30 border border-border/30 text-foreground">{user.name}</div>
              <p className="text-xs text-muted-foreground mt-2">Contact support to change your name</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email Address</label>
              <div className="p-3 rounded-lg bg-muted/30 border border-border/30 text-foreground">{user.email}</div>
              <p className="text-xs text-muted-foreground mt-2">Contact support to change your email</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Member Since</label>
              <div className="p-3 rounded-lg bg-muted/30 border border-border/30 text-foreground">{memberSince}</div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">User ID</label>
              <div className="p-3 rounded-lg bg-muted/30 border border-border/30 text-foreground font-mono text-sm">
                {user.id}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
