import { jsPDF } from "jspdf"
import type { QuizResult } from "./scoring"

export async function generateCertificatePDF(result: QuizResult) {
  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: "a4",
  })

  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()

  // Background color
  doc.setFillColor(18, 24, 38) // Dark blue background
  doc.rect(0, 0, pageWidth, pageHeight, "F")

  // Border
  doc.setDrawColor(85, 130, 255) // Blue border
  doc.setLineWidth(3)
  doc.rect(10, 10, pageWidth - 20, pageHeight - 20)

  // Inner decorative border
  doc.setDrawColor(85, 130, 255)
  doc.setLineWidth(1)
  doc.rect(15, 15, pageWidth - 30, pageHeight - 30)

  // Title
  doc.setFont("helvetica", "bold")
  doc.setFontSize(48)
  doc.setTextColor(255, 255, 255)
  doc.text("Certificate of Completion", pageWidth / 2, 50, { align: "center" })

  // Decorative line
  doc.setDrawColor(85, 130, 255)
  doc.setLineWidth(2)
  doc.line(40, 60, pageWidth - 40, 60)

  // Course name
  doc.setFont("helvetica", "normal")
  doc.setFontSize(14)
  doc.setTextColor(200, 200, 200)
  doc.text("This is to certify that", pageWidth / 2, 80, { align: "center" })

  // User name placeholder
  doc.setFont("helvetica", "bold")
  doc.setFontSize(28)
  doc.setTextColor(255, 255, 255)
  doc.text(result.userEmail || "Learner", pageWidth / 2, 100, { align: "center" })

  // Achievement text
  doc.setFont("helvetica", "normal")
  doc.setFontSize(14)
  doc.setTextColor(200, 200, 200)
  doc.text("has successfully completed the course", pageWidth / 2, 120, { align: "center" })

  // Course title
  doc.setFont("helvetica", "bold")
  doc.setFontSize(18)
  doc.setTextColor(85, 130, 255)
  doc.text(result.quizTitle, pageWidth / 2, 135, { align: "center" })

  // Score information
  doc.setFont("helvetica", "normal")
  doc.setFontSize(12)
  doc.setTextColor(200, 200, 200)
  doc.text(`with a score of ${result.score}%`, pageWidth / 2, 150, { align: "center" })

  // Certificate details section
  doc.setFontSize(11)
  doc.setTextColor(150, 150, 150)

  const issuedDate = new Date(result.timestamp).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const expiryDate = new Date(new Date(result.timestamp).getTime() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString(
    "en-US",
    {
      year: "numeric",
      month: "long",
      day: "numeric",
    },
  )

  doc.text(`Issued: ${issuedDate}`, 30, pageHeight - 50)
  doc.text(`Valid Until: ${expiryDate}`, pageWidth - 80, pageHeight - 50)

  // Certificate ID
  const certificateId = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
  doc.setFontSize(9)
  doc.setTextColor(100, 100, 100)
  doc.text(`Certificate ID: ${certificateId}`, pageWidth / 2, pageHeight - 30, { align: "center" })

  // Signature line
  doc.setDrawColor(85, 130, 255)
  doc.setLineWidth(1)
  doc.line(pageWidth / 2 - 40, pageHeight - 60, pageWidth / 2 + 40, pageHeight - 60)
  doc.setFontSize(10)
  doc.setTextColor(150, 150, 150)
  doc.text("LearnHub Administrator", pageWidth / 2, pageHeight - 55, { align: "center" })

  // Download the PDF
  const fileName = `${result.quizTitle.replace(/\s+/g, "_")}_Certificate.pdf`
  doc.save(fileName)
}
