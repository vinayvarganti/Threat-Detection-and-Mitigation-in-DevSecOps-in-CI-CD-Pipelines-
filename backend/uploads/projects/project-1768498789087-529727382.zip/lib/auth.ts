export interface User {
  id: string
  email: string
  name: string
  createdAt: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}

const STORAGE_KEY = "quiz_user"

export function saveUser(user: User): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
}

export function getUser(): User | null {
  if (typeof window === "undefined") return null
  const stored = localStorage.getItem(STORAGE_KEY)
  return stored ? JSON.parse(stored) : null
}

export function logout(): void {
  localStorage.removeItem(STORAGE_KEY)
}

export function login(email: string, name: string): User {
  const user: User = {
    id: `user_${Date.now()}`,
    email,
    name,
    createdAt: new Date().toISOString(),
  }
  saveUser(user)
  return user
}
