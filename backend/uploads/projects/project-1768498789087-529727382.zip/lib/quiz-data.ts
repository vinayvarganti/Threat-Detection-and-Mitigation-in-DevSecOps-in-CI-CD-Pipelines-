export interface Question {
  question: string
  options: string[]
  correctAnswer: number
}

export interface Quiz {
  id: string
  title: string
  description: string
  category: string
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  duration: number
  questions: Question[]
  passingScore: number
}

export const quizData: Record<string, Quiz> = {
  "web-basics": {
    id: "web-basics",
    title: "Web Development Fundamentals",
    description:
      "Learn the basics of HTML, CSS, and JavaScript. Perfect for beginners starting their web development journey.",
    category: "Web Development",
    difficulty: "Beginner",
    duration: 30,
    passingScore: 70,
    questions: [
      {
        question: "What does HTML stand for?",
        options: [
          "Hyper Text Markup Language",
          "High Tech Modern Language",
          "Home Tool Markup Language",
          "Hyperlinks and Text Markup Language",
        ],
        correctAnswer: 0,
      },
      {
        question: "Which CSS property is used to change the text color?",
        options: ["text-color", "color", "font-color", "text-style"],
        correctAnswer: 1,
      },
      {
        question: "What is the correct syntax for referring to an external script called 'xxx.js'?",
        options: [
          '<script href="xxx.js">',
          '<script name="xxx.js">',
          '<script src="xxx.js">',
          '<script file="xxx.js">',
        ],
        correctAnswer: 2,
      },
      {
        question: "How do you create a function in JavaScript?",
        options: ["function = myFunction()", "function myFunction()", "def myFunction():", "func myFunction()"],
        correctAnswer: 1,
      },
      {
        question: "Which HTML element is used for the largest heading?",
        options: ["<heading>", "<h6>", "<h1>", "<head>"],
        correctAnswer: 2,
      },
      {
        question: "What is the purpose of the <meta> tag in HTML?",
        options: [
          "To define metadata about the HTML document",
          "To create a menu",
          "To define the main content",
          "To link external stylesheets",
        ],
        correctAnswer: 0,
      },
      {
        question: "Which of the following is NOT a valid CSS unit?",
        options: ["px", "em", "rem", "xx"],
        correctAnswer: 3,
      },
      {
        question: "What does the 'var' keyword do in JavaScript?",
        options: ["Declares a variable", "Declares a constant", "Declares a function", "Declares a class"],
        correctAnswer: 0,
      },
      {
        question: "How do you add a comment in CSS?",
        options: ["// comment", "# comment", "/* comment */", "<!-- comment -->"],
        correctAnswer: 2,
      },
      {
        question: "What is the correct way to link a CSS file to an HTML document?",
        options: [
          '<link rel="stylesheet" href="style.css">',
          '<style src="style.css">',
          '<css href="style.css">',
          '<stylesheet href="style.css">',
        ],
        correctAnswer: 0,
      },
    ],
  },
  "react-advanced": {
    id: "react-advanced",
    title: "Advanced React Patterns",
    description: "Master advanced React concepts including hooks, context, and performance optimization.",
    category: "React",
    difficulty: "Advanced",
    duration: 45,
    passingScore: 75,
    questions: [
      {
        question: "What is the purpose of the useCallback hook?",
        options: [
          "To memoize callback functions and prevent unnecessary re-renders",
          "To handle async operations",
          "To manage component state",
          "To create context providers",
        ],
        correctAnswer: 0,
      },
      {
        question: "Which hook should you use to perform side effects in functional components?",
        options: ["useState", "useEffect", "useContext", "useReducer"],
        correctAnswer: 1,
      },
      {
        question: "What does the useMemo hook do?",
        options: [
          "Memoizes expensive computations",
          "Manages component state",
          "Handles async operations",
          "Creates context providers",
        ],
        correctAnswer: 0,
      },
      {
        question: "How do you prevent a component from re-rendering?",
        options: [
          "Use React.memo for functional components",
          "Use shouldComponentUpdate for class components",
          "Both A and B",
          "Use useState with useCallback",
        ],
        correctAnswer: 2,
      },
      {
        question: "What is the Context API used for?",
        options: [
          "To pass data through the component tree without prop drilling",
          "To manage component state",
          "To handle async operations",
          "To create custom hooks",
        ],
        correctAnswer: 0,
      },
    ],
  },
  "typescript-essentials": {
    id: "typescript-essentials",
    title: "TypeScript Essentials",
    description: "Understand TypeScript fundamentals and how to use types effectively in your projects.",
    category: "TypeScript",
    difficulty: "Intermediate",
    duration: 35,
    passingScore: 70,
    questions: [
      {
        question: "What is TypeScript?",
        options: [
          "A superset of JavaScript that adds static typing",
          "A replacement for JavaScript",
          "A CSS preprocessor",
          "A testing framework",
        ],
        correctAnswer: 0,
      },
      {
        question: "How do you define a type in TypeScript?",
        options: [
          "Using the 'type' keyword",
          "Using the 'interface' keyword",
          "Both A and B",
          "Using the 'class' keyword",
        ],
        correctAnswer: 2,
      },
      {
        question: "What is a generic in TypeScript?",
        options: [
          "A way to create reusable components with type parameters",
          "A type that can be any value",
          "A way to define interfaces",
          "A way to handle errors",
        ],
        correctAnswer: 0,
      },
      {
        question: "What does the 'any' type do?",
        options: [
          "Allows a variable to be any type",
          "Disables type checking for that variable",
          "Both A and B",
          "Creates a union type",
        ],
        correctAnswer: 2,
      },
      {
        question: "What is a union type?",
        options: [
          "A type that can be one of several types",
          "A type that combines multiple types",
          "A type that extends another type",
          "A type that is optional",
        ],
        correctAnswer: 0,
      },
    ],
  },
  "nextjs-fullstack": {
    id: "nextjs-fullstack",
    title: "Next.js Full Stack Development",
    description: "Build complete full-stack applications with Next.js, including API routes and database integration.",
    category: "Next.js",
    difficulty: "Advanced",
    duration: 50,
    passingScore: 75,
    questions: [
      {
        question: "What is Next.js?",
        options: [
          "A React framework for production",
          "A CSS framework",
          "A testing library",
          "A state management library",
        ],
        correctAnswer: 0,
      },
      {
        question: "What are API routes in Next.js?",
        options: [
          "Routes that serve as API endpoints",
          "Routes for rendering pages",
          "Routes for styling",
          "Routes for testing",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is Server-Side Rendering (SSR)?",
        options: [
          "Rendering pages on the server and sending HTML to the client",
          "Rendering pages on the client",
          "Rendering pages at build time",
          "Rendering pages in a worker",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is Static Site Generation (SSG)?",
        options: [
          "Generating static HTML pages at build time",
          "Generating pages on the server",
          "Generating pages on the client",
          "Generating pages in a worker",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is Incremental Static Regeneration (ISR)?",
        options: [
          "Regenerating static pages at runtime",
          "Regenerating pages on the server",
          "Regenerating pages on the client",
          "Regenerating pages in a worker",
        ],
        correctAnswer: 0,
      },
    ],
  },
  "css-mastery": {
    id: "css-mastery",
    title: "CSS Mastery",
    description: "Deep dive into CSS including flexbox, grid, animations, and responsive design techniques.",
    category: "CSS",
    difficulty: "Intermediate",
    duration: 40,
    passingScore: 70,
    questions: [
      {
        question: "What is Flexbox?",
        options: [
          "A CSS layout model for one-dimensional layouts",
          "A CSS layout model for two-dimensional layouts",
          "A CSS animation library",
          "A CSS preprocessor",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is CSS Grid?",
        options: [
          "A CSS layout model for two-dimensional layouts",
          "A CSS layout model for one-dimensional layouts",
          "A CSS animation library",
          "A CSS preprocessor",
        ],
        correctAnswer: 0,
      },
      {
        question: "What does the 'justify-content' property do in Flexbox?",
        options: [
          "Aligns items along the main axis",
          "Aligns items along the cross axis",
          "Aligns items vertically",
          "Aligns items horizontally",
        ],
        correctAnswer: 0,
      },
      {
        question: "What does the 'align-items' property do in Flexbox?",
        options: [
          "Aligns items along the cross axis",
          "Aligns items along the main axis",
          "Aligns items vertically",
          "Aligns items horizontally",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is a media query?",
        options: [
          "A CSS technique for applying styles based on device characteristics",
          "A CSS animation technique",
          "A CSS layout technique",
          "A CSS selector technique",
        ],
        correctAnswer: 0,
      },
    ],
  },
  "database-design": {
    id: "database-design",
    title: "Database Design & SQL",
    description: "Learn database design principles, normalization, and write efficient SQL queries.",
    category: "Databases",
    difficulty: "Intermediate",
    duration: 45,
    passingScore: 72,
    questions: [
      {
        question: "What is database normalization?",
        options: [
          "A process to organize data to reduce redundancy",
          "A process to encrypt data",
          "A process to backup data",
          "A process to compress data",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is a primary key?",
        options: [
          "A unique identifier for each record in a table",
          "A key that links two tables",
          "A key that encrypts data",
          "A key that sorts data",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is a foreign key?",
        options: [
          "A key that links to the primary key of another table",
          "A key that is unique in a table",
          "A key that encrypts data",
          "A key that sorts data",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is a JOIN in SQL?",
        options: [
          "A way to combine rows from two or more tables",
          "A way to filter data",
          "A way to sort data",
          "A way to group data",
        ],
        correctAnswer: 0,
      },
      {
        question: "What is an INDEX in SQL?",
        options: [
          "A data structure that improves query performance",
          "A way to filter data",
          "A way to sort data",
          "A way to group data",
        ],
        correctAnswer: 0,
      },
    ],
  },
}
