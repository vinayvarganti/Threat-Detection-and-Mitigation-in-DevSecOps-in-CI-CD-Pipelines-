export interface QuizResult {
  quizId: string
  quizTitle: string
  score: number
  passed: boolean
  correctCount: number
  totalQuestions: number
  timestamp: string
  userEmail?: string
  userName?: string
}

export interface DetailedResult extends QuizResult {
  answers: Record<number, number>
  questions: Array<{
    question: string
    userAnswer: string
    correctAnswer: string
    isCorrect: boolean
  }>
}

export function calculateScore(correctCount: number, totalQuestions: number): number {
  return Math.round((correctCount / totalQuestions) * 100)
}

export function determinePerformance(score: number): {
  level: "Excellent" | "Good" | "Fair" | "Needs Improvement"
  color: string
  message: string
} {
  if (score >= 90) {
    return {
      level: "Excellent",
      color: "text-green-600 dark:text-green-400",
      message: "Outstanding performance! You have mastered this topic.",
    }
  } else if (score >= 80) {
    return {
      level: "Good",
      color: "text-blue-600 dark:text-blue-400",
      message: "Great job! You have a solid understanding of the material.",
    }
  } else if (score >= 70) {
    return {
      level: "Fair",
      color: "text-yellow-600 dark:text-yellow-400",
      message: "Good effort! Review the material to strengthen your knowledge.",
    }
  } else {
    return {
      level: "Needs Improvement",
      color: "text-red-600 dark:text-red-400",
      message: "Keep practicing! Review the material and try again.",
    }
  }
}

export function generateCertificateData(result: QuizResult) {
  return {
    certificateId: `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    issuedDate: new Date(result.timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    expiryDate: new Date(new Date(result.timestamp).getTime() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
  }
}

export function storeResult(result: QuizResult) {
  const results = JSON.parse(sessionStorage.getItem("quizResults") || "[]")
  results.push(result)
  sessionStorage.setItem("quizResults", JSON.stringify(results))
}

export function getResult(quizId: string): QuizResult | null {
  const result = sessionStorage.getItem("quizResult")
  if (result) {
    const parsed = JSON.parse(result)
    if (parsed.quizId === quizId) {
      return parsed
    }
  }
  return null
}
