
from flask import Flask, request, render_template_string
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)')
    c.execute("INSERT INTO users (username, password) VALUES ('admin', 'admin123')")
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return '''
    <h2>Login</h2>
    <form method="POST" action="/login">
        Username: <input name="username"><br>
        Password: <input name="password" type="password"><br>
        <input type="submit">
    </form>
    <br>
    <h2>Search</h2>
    <form method="GET" action="/search">
        Search: <input name="q">
        <input type="submit">
    </form>
    '''

# SQL Injection vulnerability
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    c.execute(query)
    user = c.fetchone()
    conn.close()
    if user:
        return "Login successful!"
    return "Invalid credentials!"

# XSS vulnerability
@app.route('/search')
def search():
    query = request.args.get('q')
    return render_template_string(f"<h3>Results for: {query}</h3>")

# Command Injection vulnerability
@app.route('/ping')
def ping():
    import os
    host = request.args.get('host')
    return os.popen(f"ping -c 1 {host}").read()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
