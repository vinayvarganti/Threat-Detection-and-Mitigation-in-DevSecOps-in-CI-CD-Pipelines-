
Vulnerable Web Application (For Security Testing Practice)

Included Vulnerabilities:
1. SQL Injection (/login)
2. Reflected XSS (/search?q=)
3. Command Injection (/ping?host=)

How to run:
1. Install dependencies: pip install -r requirements.txt
2. Run: python app.py
3. Open browser: http://127.0.0.1:5000/

⚠️ This project is intentionally vulnerable.
Use ONLY in local lab environment.
